import 'dart:async';
import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:escapingplan/Modal/Favouritemodal.dart';

import 'package:escapingplan/Modal/detailmodel.dart';
import 'package:escapingplan/Modal/tripmodel.dart';

import 'package:escapingplan/Modal/viewmodel.dart';
import 'package:escapingplan/Modal/weathermodal.dart';
import 'package:escapingplan/Provider/authprovider.dart';
import 'package:escapingplan/Provider/travelprovider.dart';
import 'package:escapingplan/screen/packegedetail.dart';
import 'package:escapingplan/screen/profile2.dart';
import 'package:escapingplan/screen/weather.dart';
import 'package:escapingplan/widget/bottomnav.dart';
import 'package:escapingplan/widget/buildErrorDialog.dart';
import 'package:escapingplan/widget/const.dart';
import 'package:escapingplan/widget/drawer.dart';
import 'package:escapingplan/widget/load.dart';
import 'package:escapingplan/widget/location.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';
import '../main.dart';
class mytrips1 extends StatefulWidget {
  mytrips1({
    Key? key,
  }) : super(key: key);

  @override
  State<mytrips1> createState() => _mytrips1State();
}

class _mytrips1State extends State<mytrips1> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  String? positionString;
  Favouritemodal? favouritemodel;
  ViewModel? viewmodel;
  TripModel? tripmodel;
  int? select;
  final Set<Marker> _markers = {};
  List<Location>? placemarks;
  bool isLoading = true;
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();
  int? selectindex = 0;
  int? selectindex1 = 0;
  int? selectindex2 = 0;
  int? selectindex3 = 0;
  WeatherModal? weathermodal;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    isLoading = true;
    getdata();
  }
  getdata() async {
    await trip();
    await weatherap();
    await view();
    // getdata1(index);
  }
  getdata1(index) async {
    List<Location> locations =
        await locationFromAddress((weathermodal?.data?[index].name).toString());
    Location location = locations.first;
    setState(() {
      latitude = location.latitude;
      longitude = location.longitude;
    });
  }
  Set<Marker> _createMarker() {
    return {
      Marker(
          markerId: MarkerId(""),
          position: LatLng(latitude!, longitude!),
          infoWindow: InfoWindow(title: 'Marker 1'),
          onTap: () {
            Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => GoogleMapExample()));
          },
          rotation: 0),
      // Marker(
      //   markerId: MarkerId("marker_2"),
      //   position: LatLng(18.997962200185533, 72.8379758747611),
      // ),
    };
  }
  _onMapCreated(GoogleMapController controller) {}
  @override
  Widget build(BuildContext context) {
    return commanScreen(
      scaffold: Scaffold(
        drawer: drawer1(context),
        appBar: AppBar(
          iconTheme: IconThemeData(color: Colors.black),
          elevation: 0.0,
          backgroundColor: Colors.transparent,
          title: Padding(
            padding: EdgeInsets.symmetric(horizontal: 0.w, vertical: 2.h),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => profile2()));
                  },
                  child: Row(
                    children: [
                      Text(
                        "Hi , " + (userData?.data?[0].fullname).toString(),
                        style: TextStyle(
                            color: Colors.grey.shade700,
                            fontWeight: FontWeight.bold,
                            fontSize: 12.sp,
                            fontFamily: "Poppins"),
                      ),
                      SizedBox(width: 2.w),
                      // CircleAvatar(
                      //   child: ClipOval(
                      //     child: CachedNetworkImage(
                      //       imageUrl: viewmodel?.data?.profileImg ?? '',
                      //       imageBuilder: (context, imageProvider) => Container(
                      //         height: 90,
                      //         width: 90,
                      //         decoration: BoxDecoration(
                      //           image: DecorationImage(
                      //             image: imageProvider,
                      //             fit: BoxFit.cover,
                      //           ),
                      //         ),
                      //       ),
                      //       placeholder: (context, url) => Center(
                      //           child: CircularProgressIndicator(
                      //         color: Colors.white,
                      //       )),
                      //       errorWidget: (context, url, error) => Container(
                      //         color: Colors.white,
                      //       ),
                      //       // Image.asset('assets/profile_pic_placeholder.png'),
                      //       fit: BoxFit.cover,
                      //     ),
                      //   ),
                      // ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        body: isLoading
            ? Container()
            : (tripmodel?.status == 0)
                ? Center(child: Text("No trip available"))
                : Stack(
                    children: [
                      Container(
                        height: MediaQuery.of(context).size.height,
                        width: MediaQuery.of(context).size.width,
                        child: Padding(
                          padding: EdgeInsets.only(
                            top: 0.0,
                            bottom: 10.h,
                            left: 0.0,
                            right: 0.0,
                          ),
                          child: SingleChildScrollView(
                            physics: AlwaysScrollableScrollPhysics(),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 5.w),
                                  child: Text(
                                    "My itinerary",
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 24.sp,
                                        fontFamily: "Poppins"),
                                  ),
                                ),
                                SizedBox(
                                  height: 3.h,
                                ),
                                Container(
                                    width: MediaQuery.of(context).size.width,
                                    height: 40.h,
                                    child: ListView(
                                        scrollDirection: Axis.horizontal,
                                        children: [
                                          Container(
                                            // width: MediaQuery.of(context).size.width,
                                            height: 40.h,
                                            child: ListView.builder(
                                              physics: BouncingScrollPhysics(),
                                              shrinkWrap: true,
                                              padding: EdgeInsets.zero,
                                              scrollDirection: Axis.horizontal,
                                              itemCount:
                                                  tripmodel?.data?.length,
                                              itemBuilder: (context, index) {
                                                return GestureDetector(
                                                    onTap: () {

                                                      setState(() {
                                                        selectindex2 = index;
                                                      });
                                                      Navigator.of(context).push(MaterialPageRoute(
                                                          builder: (context) => packagedetail(
                                                              iid: (tripmodel
                                                                      ?.data?[
                                                                          index]
                                                                      .itineraryId)
                                                                  .toString(), trip : (tripmodel?.data?[index].tripplannerId))));
                                                    },
                                                    child: Stack(
                                                      children: [
                                                        Container(
                                                          height: 40.h,
                                                          width: 80.w,
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  horizontal:
                                                                      3.w,
                                                                  vertical:
                                                                      1.h),
                                                          child: ClipRRect(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        20.0),
                                                            child:
                                                                CachedNetworkImage(
                                                              imageUrl: (tripmodel?.data?[index].galleryImage ?? ""),
                                                              placeholder: (context,
                                                                      url) =>
                                                                  Center(
                                                                      child:
                                                                          CircularProgressIndicator()),
                                                              errorWidget: (context,
                                                                      url,
                                                                      error) =>
                                                                  // Container(
                                                                  //     color: Colors
                                                                  //         .white),
                                                              Image.asset('assets/profile_pic_placeholder.png'),
                                                              fit: BoxFit.cover,
                                                            ),
                                                          ),
                                                        ),
                                                        Positioned(
                                                          top: 28.h,
                                                          left: 3.w,
                                                          right: 3.w,
                                                          child: Container(
                                                            alignment: Alignment
                                                                .center,
                                                            height: 8.h,
                                                            // width:74.w,
                                                            color: Colors.black
                                                                .withOpacity(
                                                                    0.3),
                                                            child: Row(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .center,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              children: [
                                                                Expanded(
                                                                  child: Text(
                                                                    (tripmodel
                                                                            ?.data?[index]
                                                                            .title)
                                                                        .toString(),
                                                                    style: TextStyle(
                                                                        color: Colors
                                                                            .white,
                                                                        fontSize: 20
                                                                            .sp,
                                                                        fontFamily:
                                                                            "Poppins",
                                                                        fontWeight:
                                                                            FontWeight.w600),
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    maxLines: 2,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .center,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        )
                                                      ],
                                                    ));
                                              },
                                            ),
                                          ),
                                          GestureDetector(
                                            onScaleStart:
                                                (ScaleStartDetails details) {
                                              Navigator.of(context).push(
                                                  MaterialPageRoute(
                                                      builder: (context) =>
                                                          GoogleMapExample(
                                                            id1: 0,
                                                          )));
                                            },
                                            child: Container(
                                              height: 40.h,
                                              width: 80.w,
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 3.w,
                                                  vertical: 1.h),
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(20.0),
                                                child: GoogleMap(
                                                  onTap: (LatLng latLng) {
                                                    Navigator.of(context).push(
                                                        MaterialPageRoute(
                                                            builder: (context) =>
                                                                GoogleMapExample(
                                                                    id1: 0)));
                                                  },
                                                  mapType: MapType.normal,
                                                  initialCameraPosition: CameraPosition(
                                                      target: LatLng(
                                                          (weathermodal?.data?[0].coord
                                                                      ?.lat)
                                                                  ?.toDouble() ??
                                                              0.0,
                                                          (weathermodal
                                                                      ?.data?[0]
                                                                      .coord
                                                                      ?.lon)
                                                                  ?.toDouble() ??
                                                              0.0),
                                                      zoom: 3.0),
                                                  onMapCreated:
                                                      (GoogleMapController
                                                          controller) {
                                                    _controller
                                                        .complete(controller);
                                                    setState(() {
                                                      Marker(
                                                          markerId: MarkerId("marker_1"),
                                                          position: LatLng((weathermodal?.data?[0].coord?.lat)?.toDouble() ?? 0.0 ,(weathermodal?.data?[0].coord?.lon)?.toDouble() ?? 0.0),
                                                          infoWindow: InfoWindow(title: 'Marker 1'),
                                                          rotation: 0);
                                                    });
                                                  },
                                                  myLocationEnabled: true,
                                                  markers: Set<Marker>.from([
                                                    Marker(
                                                      markerId: MarkerId("loc"),
                                                      position: LatLng(
                                                          (weathermodal
                                                                      ?.data?[0]
                                                                      .coord
                                                                      ?.lat)
                                                                  ?.toDouble() ??
                                                              0.0,
                                                          (weathermodal
                                                                      ?.data?[0]
                                                                      .coord
                                                                      ?.lon)
                                                                  ?.toDouble() ??
                                                              0.0),
                                                    )
                                                  ]),
                                                ),
                                              ),
                                            ),
                                          ),
                                          InkWell(
                                            onTap: () {
                                              Navigator.of(context)
                                                  .push(MaterialPageRoute(
                                                builder: (context) =>
                                                    WeatherPage(
                                                  id1: 0,
                                                ),
                                              ));
                                            },
                                            child: Stack(
                                              children: [
                                                Container(
                                                  padding: EdgeInsets.symmetric(
                                                      horizontal: 2.w),
                                                  height: 40.h,
                                                  width: 80.w,
                                                  decoration: BoxDecoration(
                                                    image: DecorationImage(
                                                        fit: BoxFit.fill,
                                                        image: AssetImage(
                                                            "assets/escape.jpg")),
                                                    border: Border.all(
                                                        color: Colors.black),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20.0),
                                                  ),
                                                  margin: EdgeInsets.symmetric(
                                                      horizontal: 3.w,
                                                      vertical: 1.h),
                                                ),
                                                Container(
                                                  padding: EdgeInsets.symmetric(
                                                      horizontal: 2.w),
                                                  height: 40.h,
                                                  width: 80.w,
                                                  decoration: BoxDecoration(
                                                    color: Colors.black
                                                        .withOpacity(0.7),
                                                    // image: DecorationImage(
                                                    //     fit: BoxFit.fill,
                                                    //     image: AssetImage("assets/escape.jpg")),
                                                    border: Border.all(
                                                        color: Colors.black),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20.0),
                                                  ),
                                                  margin: EdgeInsets.symmetric(
                                                      horizontal: 3.w,
                                                      vertical: 1.h),
                                                  child: ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20.0),
                                                    child: Center(
                                                        child: weathermodal
                                                                    ?.data?[0]
                                                                    .main
                                                                    ?.temp ==
                                                                null
                                                            ? Container()
                                                            : Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceBetween,
                                                                    children: [
                                                                      Expanded(
                                                                        child:
                                                                            Text(
                                                                          weathermodal?.data?[0].name ??
                                                                              "",
                                                                          maxLines:
                                                                              2,
                                                                          overflow:
                                                                              TextOverflow.ellipsis,
                                                                          style: TextStyle(
                                                                              color: Colors.white,
                                                                              fontSize: 17.sp,
                                                                              fontWeight: FontWeight.w500),
                                                                        ),
                                                                      ),
                                                                      Row(
                                                                        children: [
                                                                          Text(
                                                                            '🌡️',
                                                                            style:
                                                                                TextStyle(
                                                                              fontSize: 18.sp,
                                                                            ),
                                                                          ),
                                                                          Text(
                                                                            ((weathermodal?.data?[0].main?.temp)?.toStringAsFixed(2) ?? "") +
                                                                                "°",
                                                                            style: TextStyle(
                                                                                color: Colors.white,
                                                                                fontSize: 17.sp,
                                                                                fontWeight: FontWeight.bold),
                                                                          ),
                                                                          Icon(
                                                                            Icons.arrow_forward_ios_rounded,
                                                                            color:
                                                                                Colors.white,
                                                                          )
                                                                        ],
                                                                      ),
                                                                    ],
                                                                  ),
                                                                  SizedBox(
                                                                    height: 10,
                                                                  ),
                                                                  Divider(
                                                                      color: Colors
                                                                          .grey,
                                                                      thickness:
                                                                          0.08.h),
                                                                  SizedBox(
                                                                    height: 10,
                                                                  ),
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceBetween,
                                                                    children: [
                                                                      Text(
                                                                        'Description - ',
                                                                        style: TextStyle(
                                                                            color:
                                                                                Colors.white,
                                                                            fontSize: 17.sp,
                                                                            fontWeight: FontWeight.w500),
                                                                      ),
                                                                      Row(
                                                                        children: [
                                                                          Text(
                                                                            (weathermodal?.data?[0].weather?[0].main).toString(),
                                                                            style: TextStyle(
                                                                                color: Colors.white,
                                                                                fontSize: 17.sp,
                                                                                fontWeight: FontWeight.bold),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ],
                                                                  ),
                                                                  SizedBox(
                                                                    height: 10,
                                                                  ),
                                                                  Divider(
                                                                      color: Colors
                                                                          .grey,
                                                                      thickness:
                                                                          0.08.h),
                                                                  SizedBox(
                                                                    height: 10,
                                                                  ),
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceBetween,
                                                                    children: [
                                                                      Text(
                                                                        'Clouds - ',
                                                                        style: TextStyle(
                                                                            color:
                                                                                Colors.white,
                                                                            fontSize: 17.sp,
                                                                            fontWeight: FontWeight.w500),
                                                                      ),
                                                                      Row(
                                                                        children: [
                                                                          Text(
                                                                            (weathermodal?.data?[0].clouds!.all).toString(),
                                                                            style: TextStyle(
                                                                                color: Colors.white,
                                                                                fontSize: 17.sp,
                                                                                fontWeight: FontWeight.bold),
                                                                          ),
                                                                          Text(
                                                                            ' ☁',
                                                                            style:
                                                                                TextStyle(
                                                                              fontSize: 17,
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ],
                                                              )),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ])),
                                SizedBox(
                                  height: 2.h,
                                ),
                                // Padding(
                                //   padding: EdgeInsets.symmetric(horizontal: 3.w),
                                //   child: Row(
                                //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                //     children: [
                                //       Text(
                                //         "Feeling Adventurous?",
                                //         style: TextStyle(
                                //             color: Colors.black,
                                //             fontSize: 18.sp,
                                //             fontFamily: "Poppins",
                                //             fontWeight: FontWeight.w600),
                                //         textAlign: TextAlign.center,
                                //       ),
                                //       TextButton(
                                //           onPressed: () {},
                                //           child: Text(
                                //             "Show all",
                                //             style: TextStyle(
                                //                 color: Color(0xffb4776e6),
                                //                 fontSize: 12.sp,
                                //                 fontFamily: "Poppins",
                                //                 fontWeight: FontWeight.w600),
                                //           ))
                                //     ],
                                //   ),
                                // ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 0.h,
                        left: 0.w,
                        right: 0.w,
                        child: Container(
                            height: 13.h,
                            width: MediaQuery.of(context).size.width,
                            // color: Colors.red,
                            // width: MediaQuery.of(context).size.width,
                            // padding: EdgeInsets.only(left: 5.w),
                            // decoration: BoxDecoration(
                            //     // gradient: LinearGradient(
                            //     //     begin: Alignment.bottomCenter,
                            //     //     end: Alignment.topCenter,
                            //     //     colors: [
                            //     //       Colors.blue.shade50,
                            //     //       Colors.white,
                            //     //     ]
                            //     // )
                            //
                            //     ),
                            child: BottomNavigationExample()),
                      ),
                    ],
                  ),
      ),
      isLoading: isLoading,
    );
  }

  weatherap() {
    final Map<String, String> data = {};
    data['action'] = "weatherforecast";
    data['client_id'] = userData?.data?[0].uId ?? "";
    checkInternet().then((internet) async {
      if (internet) {
        travelprovider().weatherapi(data).then((Response response) async {
          weathermodal = WeatherModal.fromJson(json.decode(response.body));
          if (response.statusCode == 200 && weathermodal?.status == 1) {
            setState(() {
              isLoading = false;
            });

            if (kDebugMode) {}
          } else {
            setState(() {
              isLoading = false;
            });
            // buildErrorDialog(context, "","Invalid login");
          }
        });
      } else {
        setState(() {
          isLoading = false;
        });
        buildErrorDialog(context, 'Error', "Internate Required");
      }
    });
  }

  view() {
    final Map<String, String> data = {};
    data['action'] = "view_profile";
    data['user_id'] = (userData?.data?[0].uId).toString();
    checkInternet().then((internet) async {
      if (internet) {
        authprovider().viewapi(data).then((Response response) async {
          viewmodel = ViewModel.fromJson(json.decode(response.body));
          if (response.statusCode == 200 && viewmodel?.status == 1) {

            setState(() {
              isLoading = false;
            });
            if (kDebugMode) {}
          } else {
            setState(() {
              isLoading = false;
            });
            // buildErrorDialog(context, "","Invalid login");
          }
        });
      } else {
        setState(() {
          isLoading = false;
        });
        buildErrorDialog(context, 'Error', "Internate Required");
      }
    });
  }

  trip() {
    final Map<String, String> data = {};
    data['client_id'] = userData?.data?[0].uId ?? "";
    data['type'] = "All";
    data['action'] = 'my_trip';
    print(data);

    checkInternet().then((internet) async {
      if (internet) {
        travelprovider().tripapi(data).then((Response response) async {
          tripmodel = TripModel.fromJson(json.decode(response.body));
          if (response.statusCode == 200 && tripmodel?.status == 1) {
            weatherap();
            setState(() {
              isLoading = false;
            });

            if (kDebugMode) {}
          } else {
            setState(() {
              isLoading = false;
            });
            buildErrorDialog(context, '',"No Itinerary");
          }
        });
      } else {
        setState(() {
          isLoading = false;
        });
        buildErrorDialog(context, 'Error', "Internate Required");
      }
    });
  }

// favouruteap() {
//   print(tripmodel?.data?[selectindex2!].itineraryId);
//   final Map<String, String> data = {};
//   data['itinerary_id'] =
//       (tripmodel?.data?[selectindex2!].itineraryId).toString();
//   data['action'] = 'favourite_trip';
//   print(data);
//
//   checkInternet().then((internet) async {
//     if (internet) {
//       travelprovider().favouriteapi(data).then((Response response) async {
//         favouritemodel = Favouritemodal.fromJson(json.decode(response.body));
//         if (response.statusCode == 200 && favouritemodel?.status == 1) {
//           setState(() {
//             isLoading = false;
//           });
//           // trip();
//
//           buildErrorDialog(context, "", (favouritemodel?.message).toString());
//         } else {
//           setState(() {
//             isLoading = false;
//           });
//         }
//       });
//     } else {
//       setState(() {
//         isLoading = false;
//       });
//       buildErrorDialog(context, 'Error', "Internate Required");
//     }
//   });
// }

// adventure() {
//   showDialog(
//     context: context,
//     builder: (context) => AlertDialog(
//       title: new Text('Select from below'),
//       content: Container(
//           height: 185.0,
//           width: MediaQuery.of(context).size.width,
//           padding: EdgeInsets.all(10.0),
//           decoration: BoxDecoration(
//             color: Colors.white,
//             borderRadius: BorderRadius.all(Radius.circular(10.0)),
//           ),
//           child: GridView.builder(
//               gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//                 mainAxisSpacing: 1.5.h,
//                 childAspectRatio: 1.3,
//                 crossAxisCount: 3,
//               ),
//               scrollDirection: Axis.vertical,
//               physics: BouncingScrollPhysics(),
//               shrinkWrap: true,
//               itemCount: icons.length,
//               itemBuilder: (context, index) {
//                 return GestureDetector(
//                   onTap: () {
//                     Navigator.of(context).pop();
//                   },
//                   child: Container(
//                     height: 10.h,
//                     width: 17.w,
//                     child: Column(
//                       children: [
//                         Container(
//                             // height: 5.h,
//                             // width: 12.w,
//                             margin: EdgeInsets.only(right: 5.w),
//                             padding: EdgeInsets.symmetric(
//                                 horizontal: 2.w, vertical: 0.h),
//                             child: Image.asset(icons[index].image.toString(),
//                                 fit: BoxFit.cover,
//                                 height: 10.w,
//                                 width: 10.w,
//                                 color: Color(0xffb4776e6))),
//                         SizedBox(
//                           height: 1.h,
//                         ),
//                         Center(
//                           child: Text(
//                             icons[index].name.toString(),
//                             style: TextStyle(
//                                 color: Colors.black,
//                                 fontSize: 8.sp,
//                                 fontFamily: "Poppins",
//                                 fontWeight: FontWeight.normal),
//                             textAlign: TextAlign.center,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 );
//               })),
//     ),
//   );
// }
}
