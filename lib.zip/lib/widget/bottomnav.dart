import 'package:escapingplan/screen/MessagePage.dart';
import 'package:escapingplan/screen/mytrips1.dart';
import 'package:escapingplan/screen/profile2.dart';
import 'package:escapingplan/screen/weather.dart';
import 'package:escapingplan/widget/location.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';


class BottomNavigationExample extends StatefulWidget {
  @override
  State<BottomNavigationExample> createState() => _BottomNavigationExampleState();
}

class _BottomNavigationExampleState extends State<BottomNavigationExample> {
  var selected=0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      bottomNavigationBar:BottomAppBar(
        clipBehavior: Clip.antiAliasWithSaveLayer,
        shape: CircularNotchedRectangle(),
        child: Container(
          height: 80.0,
          padding: EdgeInsets.symmetric(horizontal: 5.w),
          // color: Colors.pinkAccent,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                children: [
                  IconButton(onPressed: (){
                    Navigator.of(context).push(MaterialPageRoute(builder: (context)=>profile2()));
                    setState(() {
                      selected=0;
                    });
                  }, icon: Icon(Icons.person)),
                  Text("Profile",style: TextStyle(fontFamily: "Poppins",fontSize: 12.sp),)
                ],
              ),
              Column(
                children: [
                  IconButton(onPressed: (){
                    Navigator.of(context).push(MaterialPageRoute(builder: (context)=>GoogleMapExample(id1: 0,)));
                    setState(() {
                      selected=1;
                    });
                  }, icon: Icon(Icons.map_outlined)),
                  Text("Map",style: TextStyle(fontFamily: "Poppins",fontSize: 12.sp),)
                ],
              ),
              Column(
                children: [
                  IconButton(onPressed: (){
                    Navigator.of(context).push(MaterialPageRoute(builder: (context)=>WeatherPage(id1:0)));
                    setState(() {
                      selected=2;
                    });
                  }, icon: Icon(Icons.cloudy_snowing)),
                  Text("Weather",style: TextStyle(fontFamily: "Poppins",fontSize: 12.sp),)
                ],
              ),
              Column(
                children: [
                  IconButton(onPressed: (){
                    Navigator.of(context).push(MaterialPageRoute(builder: (context)=>MessagePage()));
                    setState(() {
                      selected=3;
                    });
                  }, icon: Icon(Icons.chat)),
                  Text("Chat",style: TextStyle(fontFamily: "Poppins",fontSize: 12.sp),)
                ],
              ),
            ],
          ),
        ),
      ),
      // BottomNavigationBar(
      //   selectedItemColor: Color(0xffb4776e6),
      //   unselectedItemColor: Colors.black,
      //   backgroundColor: Colors.red.shade100,
      //   onTap: (index)
      //   {
      //     setState(() {
      //       selected=index;
      //     });
      //   },
      //   currentIndex: selected,
      //   items: [
      //     BottomNavigationBarItem(
      //
      //         icon: GestureDetector(
      //             onTap: (){
      //               Navigator.of(context).push(MaterialPageRoute(builder: (context)=>profile2()));
      //             },
      //             child: Column(
      //               children: [
      //                 Icon(Icons.people),
      //                 // Text("Profile")
      //               ],
      //             )),
      //         label: "Profile"
      //     ),
      //     BottomNavigationBarItem(
      //         icon: GestureDetector(
      //             onTap: (){
      //               Navigator.of(context).push(MaterialPageRoute(builder: (context)=>GoogleMapExample()));
      //             },
      //             child: Column(
      //               children: [
      //                 Icon(Icons.map_outlined),
      //                 // Text("Map")
      //               ],
      //             )),
      //         label: "Map"
      //     ),
      //     BottomNavigationBarItem(
      //         icon: GestureDetector(
      //             onTap:(){
      //               Navigator.of(context).push(MaterialPageRoute(builder: (context)=>WeatherPage()));
      //         },child: Column(
      //           children: [
      //             Icon(Icons.cloudy_snowing),
      //             // Text("Weather")
      //           ],
      //         )),
      //         label: "Weather"
      //     ),
      //     BottomNavigationBarItem(
      //         icon: GestureDetector(
      //             onTap: (){
      //               Navigator.of(context).push(MaterialPageRoute(builder: (context)=>MessagePage()));
      //             },
      //             child: Column(
      //               children: [
      //                 Icon(Icons.chat),
      //                 // Text("Chat")
      //               ],
      //             )),
      //         label: "Chat"
      //     ),
      //
      //   ],
      // ),
      // body: (selected==0)?mytrips1():(selected==1)?GoogleMapExample():(selected==2)?WeatherPage():MessagePage(),
      // body: SingleChildScrollView(
      //   child: Column(
      //     children: [
      //       (selected==0)?Text("Home Tab"):Visibility(child: Text("Demo"),visible: false),
      //       (selected==1)?Text("About Tab"):Visibility(child: Text("Demo"),visible: false),
      //       (selected==2)?Text("Settings Tab"):Visibility(child: Text("Demo"),visible: false),
      //     ],
      //   ),
      // )
    );
  }
}