// import 'dart:async';
//
// import 'package:flutter/material.dart';
// import 'package:geolocator/geolocator.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'package:location/location.dart';
//
// class location1 extends StatefulWidget {
//   const location1({Key? key}) : super(key: key);
//
//   @override
//   State<location1> createState() => _location1State();
// }
//
// class _location1State extends State<location1> {
//   GoogleMapController? _controller;
//
//   Set<Marker> _markers={};
//   void getLocation() async{
//     // await FirebaseFirestore.instance.collection("Location").doc("5hGxSAVPSPwgIMcNGRxM").get().then((document) async{
//     //   var icon = await BitmapDescriptor.fromAssetImage(ImageConfiguration(devicePixelRatio: 3.2),"img/img11.png");
//     //   setState(() {
//     //     this.icon = icon;
//     //   });
//     //   setState(() {
//     //     _markers.add(Marker(markerId: MarkerId('Home'),
//     //         icon: icon,
//     //         position: LatLng(double.parse(document["lattitude"]),double.parse(document["longtitude"]))
//     //     ));
//     //   });
//     // });
//
//     var icon = await BitmapDescriptor.fromAssetImage(ImageConfiguration(devicePixelRatio: 3.2),"img/img11.png");
//     setState(() {
//       // this.icon = icon;
//     });
//     var location = await currentLocation.getLocation();
//     currentLocation.onLocationChanged.listen((LocationData loc){
//       _controller?.animateCamera(CameraUpdate.newCameraPosition(new CameraPosition(
//         target: LatLng(loc.latitude ?? 0.0,loc.longitude?? 0.0),
//         zoom: 12.0,
//       )));
//       print(loc.latitude);
//       print(loc.longitude);
//       setState(() {
//        _markers.add(Marker(markerId: MarkerId('Home'),
//             icon: icon,
//             position: LatLng(loc.latitude ?? 0.0, loc.longitude ?? 0.0)
//         ));
//        _markers.add(Marker(markerId: MarkerId('Adajan'),
//            icon: icon,
//            position: LatLng(21.1959,72.7933)
//        ));
//        _markers.add(Marker(markerId: MarkerId('Rander'),
//            icon: icon,
//            position: LatLng(21.2189,72.7961)
//        ));
//       });
//     });
//   }
//
//
//
//   @override
//   Widget build(BuildContext context) {
//     return  Scaffold(
//       body:GoogleMap(
//         mapType: MapType.normal,
//           initialCameraPosition: CameraPosition(
//             target: LatLng(21.1702,72.8311),
//             zoom: 14.4746,
//           ),
//         onMapCreated: (GoogleMapController controller) {
//           _controller = controller;
//           getLocation();
//
//         },
//       ),
//       floatingActionButton: FloatingActionButton.extended(
//         onPressed:()async{
//
//         },
//         label: const Text('To the lake!'),
//         icon: const Icon(Icons.directions_boat),
//       ),
//     );
//   }
//
// }
import 'dart:async';
import 'dart:convert';


import 'package:escapingplan/Modal/detailmodel.dart';
import 'package:escapingplan/Provider/travelprovider.dart';
import 'package:escapingplan/widget/buildErrorDialog.dart';
import 'package:escapingplan/widget/const.dart';
import 'package:escapingplan/widget/load.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart';
import 'package:sizer/sizer.dart';
class GoogleMapExample1 extends StatefulWidget {
  String? loc;
  GoogleMapExample1({Key? key,this.loc}) : super(key: key);

  @override
  State<GoogleMapExample1> createState() => _GoogleMapExample1State();
}
double? latitude = 0.0;
double? longitude = 0.0;
class _GoogleMapExample1State extends State<GoogleMapExample1> {
  final Set<Marker> _markers = {};
  // String address = "Surat,Gujarat";
  // var currentLocation = LocationData;
  List<Location>? placemarks;
  bool isLoading = true;
  final Completer<GoogleMapController> _controller =
  Completer<GoogleMapController>();
  getaddress()async{
    String? positionString = detailmodal?.latlong;
    print(positionString);

    List<String>? parts = positionString!.split(",");
    setState(() {
      latitude = double.parse(parts[0]);
      longitude = double.parse(parts[1]);
    });
    // placemarks =  await locationFromAddress ((detailmodal?.location).toString());
    // setState((){
    //   placemarks;
    //   // latitude = placemarks?[0].latitude;
    //   // longitude = placemarks?[0].longitude;
    //   // _center = LatLng( latitude!,longitude!);
    // });
    //
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // isLoading=true;
    detailap();
    getaddress();
    print(widget.loc);
    // _timer = Timer.periodic(Duration(seconds: 10), (Timer t) => getLocation());
  }
  Set<Marker> _createMarker() {
    return {
      Marker(
          markerId: MarkerId("marker_1"),
          position:LatLng(latitude!,longitude!),
          infoWindow: InfoWindow(title: 'Marker 1'),
          rotation: 0),
      // Marker(
      //   markerId: MarkerId("marker_2"),
      //   position: LatLng(18.997962200185533, 72.8379758747611),
      // ),
    };
  }
  void _onMapCreated(GoogleMapController controller) {
    _controller.complete(controller);
    setState(() {
      Marker(
          markerId: MarkerId("marker_1"),
          position: LatLng(latitude!,longitude!),
          infoWindow: InfoWindow(title: 'Marker 1'),
          rotation: 0);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
          height: 40.h,
          width: 90.w,
          child: GoogleMap(
            mapType: MapType.normal,
            initialCameraPosition:CameraPosition(
                target:LatLng(latitude!,longitude!),
                zoom: 3.0
            ),
            onMapCreated: _onMapCreated,
            myLocationEnabled: true,
            markers: _createMarker(),
          ),
        ),
        // floatingActionButton: FloatingActionButton.extended(
        //   onPressed: _goToTheLake,
        //   label: const Text('To the lake!'),
        //   icon: const Icon(Icons.directions_boat),
        // ),
    );

  }
  detailap() {

    final Map<String, String> data = {};
    data['itinerary_id'] = widget.loc.toString();
    data['action'] = 'detail_page';
    checkInternet().then((internet) async {
      if (internet) {
        travelprovider().detailapi(data).then((Response response) async {
          detailmodal = DetailModel.fromJson(json.decode(response.body));
          if (response.statusCode == 200 && detailmodal?.status == 1) {
            setState(() {
              // isLoading = false;
            });
            if (kDebugMode) {}
          } else {
            setState(() {
              // isLoading = false;
            });
            // buildErrorDialog(context, "", "Invalid login");
          }
        });
      } else {
        setState(() {
          // isLoading = false;
        });
        buildErrorDialog(context, 'Error', "Internate Required");
      }
    });
  }
}

