// import 'dart:async';
//
// import 'package:flutter/material.dart';
// import 'package:geolocator/geolocator.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'package:location/location.dart';
//
// class location1 extends StatefulWidget {
//   const location1({Key? key}) : super(key: key);
//
//   @override
//   State<location1> createState() => _location1State();
// }
//
// class _location1State extends State<location1> {
//   GoogleMapController? _controller;
//
//   Set<Marker> _markers={};
//   void getLocation() async{
//     // await FirebaseFirestore.instance.collection("Location").doc("5hGxSAVPSPwgIMcNGRxM").get().then((document) async{
//     //   var icon = await BitmapDescriptor.fromAssetImage(ImageConfiguration(devicePixelRatio: 3.2),"img/img11.png");
//     //   setState(() {
//     //     this.icon = icon;
//     //   });
//     //   setState(() {
//     //     _markers.add(Marker(markerId: MarkerId('Home'),
//     //         icon: icon,
//     //         position: LatLng(double.parse(document["lattitude"]),double.parse(document["longtitude"]))
//     //     ));
//     //   });
//     // });
//
//     var icon = await BitmapDescriptor.fromAssetImage(ImageConfiguration(devicePixelRatio: 3.2),"img/img11.png");
//     setState(() {
//       // this.icon = icon;
//     });
//     var location = await currentLocation.getLocation();
//     currentLocation.onLocationChanged.listen((LocationData loc){
//       _controller?.animateCamera(CameraUpdate.newCameraPosition(new CameraPosition(
//         target: LatLng(loc.latitude ?? 0.0,loc.longitude?? 0.0),
//         zoom: 12.0,
//       )));
//       print(loc.latitude);
//       print(loc.longitude);
//       setState(() {
//        _markers.add(Marker(markerId: MarkerId('Home'),
//             icon: icon,
//             position: LatLng(loc.latitude ?? 0.0, loc.longitude ?? 0.0)
//         ));
//        _markers.add(Marker(markerId: MarkerId('Adajan'),
//            icon: icon,
//            position: LatLng(21.1959,72.7933)
//        ));
//        _markers.add(Marker(markerId: MarkerId('Rander'),
//            icon: icon,
//            position: LatLng(21.2189,72.7961)
//        ));
//       });
//     });
//   }
//
//
//
//   @override
//   Widget build(BuildContext context) {
//     return  Scaffold(
//       body:GoogleMap(
//         mapType: MapType.normal,
//           initialCameraPosition: CameraPosition(
//             target: LatLng(21.1702,72.8311),
//             zoom: 14.4746,
//           ),
//         onMapCreated: (GoogleMapController controller) {
//           _controller = controller;
//           getLocation();
//
//         },
//       ),
//       floatingActionButton: FloatingActionButton.extended(
//         onPressed:()async{
//
//         },
//         label: const Text('To the lake!'),
//         icon: const Icon(Icons.directions_boat),
//       ),
//     );
//   }
//
// }
import 'dart:async';
import 'dart:convert';


import 'package:escapingplan/Modal/weathermodal.dart';
import 'package:escapingplan/Provider/travelprovider.dart';
import 'package:escapingplan/widget/buildErrorDialog.dart';
import 'package:escapingplan/widget/const.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart';
import 'package:sizer/sizer.dart';

import '../main.dart';




class GoogleMapExample extends StatefulWidget {
    int? id1;

  GoogleMapExample({Key? key,this.id1}) : super(key: key);
  @override
  State<GoogleMapExample> createState() => _GoogleMapExampleState();
}

class _GoogleMapExampleState extends State<GoogleMapExample> {
bool  isLoading = true;
int? id=0;

    WeatherModal? weathermodal;
  final Set<Marker> _markers = {};
  // String address = "Surat,Gujarat";
  // var currentLocation = LocationData;
  List<Location>? placemarks;
GoogleMapController? _controller;
  // final Completer<GoogleMapController> _controller =
  // Completer<GoogleMapController>();
  getaddress()async{

    List<Location> locations = await locationFromAddress (weathermodal?.data?[id!].name ?? "");
    Location location = locations.first;
    setState(() {
      latitude = location.latitude;
      longitude = location.longitude;
    });
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    weather();
    setState(() {
      id = widget.id1;
    });

    // _timer = Timer.periodic(Duration(seconds: 10), (Timer t) => getLocation());
        }
Set<Marker> _createMarker() {
  return {
    Marker(
        markerId: MarkerId("marker_1"),
        position:LatLng(latitude!,longitude!),
        infoWindow: InfoWindow(title: 'Marker 1'),
        rotation: 0),
  };
}
void _onMapCreated(GoogleMapController controller) {

  // _controlle?.complete(controller);
  setState(() {
    _controller= controller;
    Marker(
        markerId: MarkerId("marker_1"),
        position: LatLng(latitude!,longitude!),
        infoWindow: InfoWindow(title: 'Marker 1'),
        rotation: 0);
  });
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Location"),
        automaticallyImplyLeading: true,
      ),
      body:isLoading?Container():
      Stack(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: GestureDetector(
              // onScaleStart: (details) {
              //   _previousZoom = _getCurrentZoom();
              // },
              // onScaleUpdate: (details) {
              //   final double zoom = _previousZoom / details.scale;
              //   _controller?.animateCamera(CameraUpdate.zoomTo(zoom));
              // },
              child: GoogleMap(
                // minMaxZoomPreference:
                // MinMaxZoomPreference(0, 5),
                zoomControlsEnabled: true,
                zoomGesturesEnabled: true,
                scrollGesturesEnabled: true,

                mapType: MapType.normal,
                initialCameraPosition:CameraPosition(
                    target:LatLng(latitude!,longitude!),
                  zoom: 3
                ),
                onMapCreated: _onMapCreated,
                myLocationEnabled: true,
                markers: _createMarker(),
              ),
            ),
          ),
          weathermodal?.data?.length == 1 ?Container(): Container(
              width:MediaQuery.of(context).size.width,
              height:8.h,
              color:Colors.white,
              // color: Colors.black.withOpacity(0.7),
              // color: Colors.black.withOpacity(0.7),
              child:ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount:weathermodal?.data?.length ,
                itemBuilder: (context,index){
                  return GestureDetector(
                    onTap: (){
                      setState(() {
                        id =index;
                      });
                      weather();
                    },
                    child: Container(
                        alignment: Alignment.center,
                        width: 30.w,
                        margin: EdgeInsets.only(left: 3.w,top:3.w,bottom: 3.w),
                        padding: EdgeInsets.all(2.w),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20.0),

                            border:Border.all( width:2,
                                color:(id == index) ?Colors.blue: Colors.black)),
                        // ),


                        child:Text(weathermodal?.data?[index].name ?? "",
                          style: TextStyle(
                              color:(id== index)?Colors.blueAccent: Colors.black,
                              fontSize: 12.sp,
                              fontWeight: FontWeight.bold,
                              fontFamily: "Poppins"
                          ),)
                    ),
                  );
                },
              )
          ),
        ],
      ),

    );
  }
weather() {
  final Map<String, String> data = {};
  data['action'] = "weatherforecast";
  data['client_id'] = userData?.data?[0].uId ?? "";
  checkInternet().then((internet) async {
    if (internet) {
      travelprovider().weatherapi(data).then((Response response) async {
        weathermodal = WeatherModal.fromJson(json.decode(response.body));
        if (response.statusCode == 200 && weathermodal?.status == 1) {
          getaddress();
          _createMarker();


          setState(() {
            isLoading = false;

          });
          if (kDebugMode) {}
        } else {
          setState(() {
            isLoading = false;
          });
          // buildErrorDialog(context, "","Invalid login");
        }
      });
    } else {
      setState(() {
        isLoading = false;
      });
      buildErrorDialog(context, 'Error', "Internate Required");
    }
  });
}

}


