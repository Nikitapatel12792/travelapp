class UserModal {
  int? status;
  String? message;
  List<Data>? data;

  UserModal({this.status, this.message, this.data});

  UserModal.fromJson(Map<dynamic, dynamic> json) {
    status = json['status'];
    message = json['message'];
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(new Data.fromJson(v));
      });
    }
  }

  Map<dynamic, dynamic> toJson() {
    final Map<dynamic, dynamic> data = new Map<dynamic, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  String? uId;
  String? itineraryId;
  String? email;
  String? fullname;
  String? type;
  String? clientId;
  String? clientName;
  String? profileImg;

  Data(
      {this.uId,
        this.itineraryId,
        this.email,
        this.fullname,
        this.type,
        this.clientId,
        this.clientName,
        this.profileImg});

  Data.fromJson(Map<dynamic, dynamic> json) {
    uId = json['u_id'];
    itineraryId = json['itinerary_id'];
    email = json['email'];
    fullname = json['fullname'];
    type = json['type'];
    clientId = json['client_id'];
    clientName = json['client_name'];
    profileImg = json['profile_img'];
  }

  Map<dynamic, dynamic> toJson() {
    final Map<dynamic, dynamic> data = new Map<dynamic, dynamic>();
    data['u_id'] = this.uId;
    data['itinerary_id'] = this.itineraryId;
    data['email'] = this.email;
    data['fullname'] = this.fullname;
    data['type'] = this.type;
    data['client_id'] = this.clientId;
    data['client_name'] = this.clientName;
    data['profile_img'] = this.profileImg;
    return data;
  }
}
