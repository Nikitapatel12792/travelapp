class Partnersmodal {
  int? status;
  String? message;
  List<LuggageDetail>? luggageDetail;
  List<InsuranceDet>? insuranceDet;
  List<BeautyDetail>? beautyDetail;
  List<SwimwearDetail>? swimwearDetail;

  Partnersmodal(
      {this.status,
        this.message,
        this.luggageDetail,
        this.insuranceDet,
        this.beautyDetail,
        this.swimwearDetail});

  Partnersmodal.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    if (json['luggage_detail'] != null) {
      luggageDetail = <LuggageDetail>[];
      json['luggage_detail'].forEach((v) {
        luggageDetail!.add(new LuggageDetail.fromJson(v));
      });
    }
    if (json['insurance_det'] != null) {
      insuranceDet = <InsuranceDet>[];
      json['insurance_det'].forEach((v) {
        insuranceDet!.add(new InsuranceDet.fromJson(v));
      });
    }
    if (json['beauty_detail'] != null) {
      beautyDetail = <BeautyDetail>[];
      json['beauty_detail'].forEach((v) {
        beautyDetail!.add(new BeautyDetail.fromJson(v));
      });
    }
    if (json['swimwear_detail'] != null) {
      swimwearDetail = <SwimwearDetail>[];
      json['swimwear_detail'].forEach((v) {
        swimwearDetail!.add(new SwimwearDetail.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.luggageDetail != null) {
      data['luggage_detail'] =
          this.luggageDetail!.map((v) => v.toJson()).toList();
    }
    if (this.insuranceDet != null) {
      data['insurance_det'] =
          this.insuranceDet!.map((v) => v.toJson()).toList();
    }
    if (this.beautyDetail != null) {
      data['beauty_detail'] =
          this.beautyDetail!.map((v) => v.toJson()).toList();
    }
    if (this.swimwearDetail != null) {
      data['swimwear_detail'] =
          this.swimwearDetail!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class LuggageDetail {
  String? partnerName;
  String? partnerImage;
  String? partnerLink;

  LuggageDetail({this.partnerName, this.partnerImage, this.partnerLink});

  LuggageDetail.fromJson(Map<String, dynamic> json) {
    partnerName = json['partner_name'];
    partnerImage = json['partner_image'];
    partnerLink = json['partner_link'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['partner_name'] = this.partnerName;
    data['partner_image'] = this.partnerImage;
    data['partner_link'] = this.partnerLink;
    return data;
  }
}
class InsuranceDet {
  String? partnerName;
  String? partnerImage;
  String? partnerLink;

  InsuranceDet({this.partnerName, this.partnerImage, this.partnerLink});

  InsuranceDet.fromJson(Map<String, dynamic> json) {
    partnerName = json['partner_name'];
    partnerImage = json['partner_image'];
    partnerLink = json['partner_link'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['partner_name'] = this.partnerName;
    data['partner_image'] = this.partnerImage;
    data['partner_link'] = this.partnerLink;
    return data;
  }
}
class BeautyDetail {
  String? partnerName;
  String? partnerImage;
  String? partnerLink;

  BeautyDetail({this.partnerName, this.partnerImage, this.partnerLink});

  BeautyDetail.fromJson(Map<String, dynamic> json) {
    partnerName = json['partner_name'];
    partnerImage = json['partner_image'];
    partnerLink = json['partner_link'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['partner_name'] = this.partnerName;
    data['partner_image'] = this.partnerImage;
    data['partner_link'] = this.partnerLink;
    return data;
  }
}
class SwimwearDetail {
  String? partnerName;
  String? partnerImage;
  String? partnerLink;

  SwimwearDetail({this.partnerName, this.partnerImage, this.partnerLink});

  SwimwearDetail.fromJson(Map<String, dynamic> json) {
    partnerName = json['partner_name'];
    partnerImage = json['partner_image'];
    partnerLink = json['partner_link'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['partner_name'] = this.partnerName;
    data['partner_image'] = this.partnerImage;
    data['partner_link'] = this.partnerLink;
    return data;
  }
}

